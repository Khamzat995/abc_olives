const products = [
    {
        id: 1,
        image: "./img/products/olive_vakum_1.webp",
        name: "SIOURAS",
        price: 4.2,
        discr: "box-diskr1",
        btn: "span-box"
        /*  discr: "Оливки натуральные с косточкой, вакуум 250 гр..." */
    },
    {
        id: 2,
        image: "./img/products/olive_vakum_3.webp",
        name: "SIOURAS",
        price: 3.8,
        discr: "box-diskr2",
        btn: "span-box"
        /*  discr: "Оливки зеленые пряные с перцем, вакуум 250 гр..." */
    },
    {
        id: 3,
        image: "./img/products/olive_metal_1.webp",
        name: "CALYPSO",
        price: 6.4,
        discr: "box-diskr3",
        btn: "span-box"
        /* discr: "Маслины натуральные без косточки, метал 850 гр... " */
    },
    {
        id: 4,
        image: "./img/products/olive_metal_2.webp",
        name: "CALYPSO",
        price: 6.2,
        discr: "box-diskr4",
        btn: "span-box"
        /*  discr: "Оливки зеленые с косточкой, метал 850 гр..." */
    },
    {
        id: 5,
        image: "./img/products/olive_big_3.webp",
        name: "SERRATA",
        price: 50.5,
        discr: "box-diskr5",
        btn: "span-box"
        /* discr: "Оливковое масло рафинированное, метал 5 литров..." */
    },
    {
        id: 6,
        image: "./img/products/olive_big_1.webp",
        name: "KALAMATA",
        price: 45.2,
        discr: "box-diskr6",
        btn: "span-box"
        /* discr: "Оливковое масло Extra Virgin, метал 3 литра..." */
    }
]

